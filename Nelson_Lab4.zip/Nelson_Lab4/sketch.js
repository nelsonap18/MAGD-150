let radius = 50;
let r = -radius;
let speed = 1.25;
let y = 0;
let x = 0;
let fr = 40;

function setup () {
  createCanvas (400, 400);
  colorMode(RGB, 255, 255, 255);
  frameRate(fr);
}
 
function draw () {
  background(180);
  strokeWeight(4);
  stroke(255);
  
  r += speed;
  if (r > width+radius) {
   r = -radius;
  }

  for (x = 0; x <= width; x += 100) {
    for (y = 0; y<= height; y +=100) {
     fill(random(250), 0, random(250));
     ellipse(r, y, 100, 100);
  }
  if (mouseIsPressed) {
    for (x = 0; x <= width; x += 100) {
    for (y = 0; y <= height; y += 100) {
     fill(0, 0, random(255));
     ellipse(r, y, 100, 100);
    }
   }
  }
  if (keyIsPressed) {
    for (x = 0; x <= width; x += 100) {
    for (y = 0; y <= height; y += 100) {
     fill(0, random(250), random(250));
     ellipse(x, r, 100, 100);
    }
   }
  } 
 }
}
