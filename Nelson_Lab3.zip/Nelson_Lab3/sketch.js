let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 20;
let x = 100;
let y = 100;
let w = 250;
let h = 50;
let r = 20;


function setup() {
createCanvas(400, 400);
  frameRate(fr);
  background(100);
  noStroke();
  fill(156, 224, 20);
  rect(h, h, x, y);
  fill(224, 136, 20);
  rect(w, h, x, y);
  fill(20, 224, 224);
  rect(h, w, x, y);
  fill(224, 20, 74);
  rect(w, w, x, y);
}

function draw() {
colorMode(RGB, 255, 255, 255, 1);
      
  let mx = mouseX;
  let my = mouseY;
  let px = pmouseX;
  let py = pmouseY;

  stroke(173, 20, 224, 0.5);
  strokeWeight(8);
  line(mx, my, px, py);
  noStroke();
    
  // w = 250, x = 100, y = 100, h = 50
  //orange square
if ((mx > w) && (mx < x+w) &&
    (my > h) && (my < y+h)) {
   noStroke();
  fill(18, 142, 219, 0.4);
  ellipse(mx, my, pow(r, 1.5), pow(r, 1.5));
}
  
  // w = 250, x = 100, y = 100, h = 50
  //red square
if ((mx > w) && (mx < x+w) &&
    (my > h) && (my < w+x*2) && (my > w)) {
  fill(69, 204, 20, 0.4);
  ellipse(mx, my, sqrt(x*r), sqrt(x*r));
} 

  // w = 250, x = 100, y = 100, h = 50
  // green square
if ((mx < x+h) && (mx > h) &&
    (my > h) && (my < x+h)) {
  fill(222, 20, 57, 0.4);
  ellipse(mx, my, sqrt(x*r), sqrt(x*r));
}

  // w = 250, x = 100, y = 100, h = 50
  //blue square
if ((mx < x+h) && (mx > h) &&
    (my > w) && (my < w+x)) {
  fill(227, 131, 14, 0.4);
  ellipse(mx, my, pow(r, 1.5), pow(r, 1.5));
 }
}
