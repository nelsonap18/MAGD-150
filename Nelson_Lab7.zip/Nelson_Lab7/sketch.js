//I call this project "Snowstorm"

var snow = [];
var x = [];
var y = [];
var wind = 50;
var printArray = [5, 6, 7, 8, 1, 2, 24, 3, 348, 4, 9, 10, 34, 55, 645, 3, 2, 44, 11, 7643, 23, 567];

function setup() {
  createCanvas(600, 400);
  angleMode(DEGREES);
  frameRate(10);

  print(printArray.length);

  for (var i = 0; i < 300; i++) {
    snow[i] = random(-200, 600);
  }
  
  for (var a = 0; a < wind; a++) {
    x[a] = 0;
    y[a] = 0;
  }
}

function draw() {
  background(0);
  noStroke();

  triangle(50, 75, 75, 275, 25, 275); //far left tree
  rect(40, 275, 20, 25);
    
  push(); //far right tree
  translate(500, 0);
  triangle(50, 75, 75, 275, 25, 275);
  rect(40, 275, 20, 25);
  pop();

  push(); //smaller right tree
  fill(180);
  scale(0.75);
  translate(400, 100);
  triangle(50, 75, 75, 275, 25, 275);
  rect(40, 275, 20, 25);
  pop();

  push(); //smaller left tree
  fill(150);
  scale(0.5);
  translate(200, 300);
  triangle(50, 75, 75, 275, 25, 275);
  rect(40, 275, 20, 25);
  pop();
  
  for (var a = wind - 1; a > 0; a--) {
    x[a] = x[a - 1];
    y[a] = y[a - 1];
  }
  x[0] = mouseX
  y[0] = mouseY

  for (a = 0; a < wind; a++) {
    fill(a*3, 80);
    ellipse(x[a], y[a], 150, 75);
  }
    
  fill(190);
  rect(0, 300, 600, 100); 
  
  push();  //smaller front tree
  fill(230);
  scale(0.75);
  translate(200, 200);
  triangle(50, 75, 75, 275, 25, 275);
  rect(40, 275, 20, 25);
  pop();
  
  push(); //larger front tree
  fill(230);
  scale(1.5);
  translate(250, -30);
  triangle(50, 75, 75, 275, 25, 275);
  rect(40, 275, 20, 25);
  pop();
  
  for (i = 0; i < snow.length; i++) {
    push();
    
    snow[i] += 0.5
    var k = i * 4;
    
    translate(500, -100);
    scale(random(0.5, 1.5));
    rotate(random(45, 135));
    
    snowflake(k, snow[i]);
    
    pop();
  }
}

function snowflake(x, y) {
  push();

  translate(x, y);

  stroke(255);
  strokeWeight(1);

  line(0, 0, 25, 25);
  line(25, 0, 0, 25);
  line(25 / 2, 3, 25 / 2, 22);
  line(3, 25 / 2, 22, 25 / 2);

  line(20, -3, 20, 5);
  line(28, 5, 20, 5);

  line(5, -3, 5, 5);
  line(-4, 5, 5, 5);

  line(-4, 20, 5, 20);
  line(5, 20, 5, 29);

  line(28, 20, 20, 20);
  line(20, 20, 20, 29);

  ellipse(-1, -1, 3, 3);
  ellipse(26, 26, 3, 3);
  ellipse(-1, 26, 3, 3);
  ellipse(26, -2, 3, 3);

  ellipse(25 / 2, 1, 3, 3);
  ellipse(24, 25 / 2, 3, 3);
  ellipse(25 / 2, 24, 3, 3);
  ellipse(1, 25 / 2, 3, 3);

  noFill();
  quad(25 / 2, 3, 22, 25 / 2, 25 / 2, 22, 3, 25 / 2);

  pop();
}