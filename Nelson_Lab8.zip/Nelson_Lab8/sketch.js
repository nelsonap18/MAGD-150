var img1;
var img2;
var gif;

function preload() {
  img1 = loadImage('title.jpg');
  img2 = loadImage('castle.jpg');
  gif = loadImage('giphy.gif');
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(199, 226, 237);

push();
  fill(204, 8, 90);
  strokeWeight(0.75);
  stroke(125, 6, 62);

  textFont("Lobster");
  textSize(27);
  text("Walt Disney's Cinderella", 330, 50);
pop();

push();
  textFont("Lobster");
  fill(204, 8, 90);
  textSize(20);
  text("Fun Facts About the Film:", 20, 280);
pop();

push();
  fill(12, 51, 122);
  textFont("Helvetica");
  
  textSize(10);
  text("The scene where Cinderella’s dress transforms from an old, worn rag to her iconic ball gown was Walt Disney’s favorite work of animation.", 20, 290, 248, 200); 
  text("The film became the greatest critical and commercial hit for the studio since Snow White and the Seven Dwarfs   (1937) and saved the studio from going bankrupt.", 20, 340, 248, 200);   
  
  textSize(16);
  text("Released in 1950", 400, 75);
pop();


  image(img2, 280, 125, mouseX + 50, mouseY);

  image(img1, 20, 20, 300, 223.75);
  
  image(gif, mouseX - 160, mouseY - 160, 320, 215.3);
}